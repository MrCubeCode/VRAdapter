using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.XR.PXR;
using UnityEngine.SceneManagement;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Windows;
using UnityEngine.XR;
using Zinnia.Event.Yield;


namespace Unity.XR.PXR
{

    public class Adapt : MonoBehaviour
    {
        public string handLeftName;
        public string handRightName;
        public string cameraName;
        public string canvasName;
        bool hideHand;

        public GameObject canvasParent;
        public GameObject controlerModelRight;
        public GameObject controlerModelLeft;
        private int selected;
        private InputDevice currentController;
        private float grip;
        private float trigger;
        private bool button;
        private PXR_Input.Controller controller;
        public GameObject handLeft;
        public GameObject handRight;
        public GameObject vrCamera;
        private bool bA;
        private int time;
        private GameObject canvasC;

        private GameObject gameCamera;
        public GameObject offsetColibration;
        private float offsetY;
        public void StartVrFunctions()
        {
            if (cameraName != "")
            {
                gameCamera = GameObject.Find(cameraName);
            }
            else
            {
                for (int i = 0; i < Camera.allCameras.Length; i++)
                {
                    if (Camera.allCameras[i].targetTexture == null && Camera.allCameras[i].gameObject != vrCamera)
                    {
                        gameCamera = Camera.allCameras[i].gameObject;
                        break;
                    }

                }
            }
            InputObjectVr.VrAdapterObject = gameObject;
            InputObjectVr.VrAdapterInput = gameObject.GetComponent<KeySimulate>();
            offsetY = vrCamera.transform.localPosition.y;
            
           
            offsetColibration.transform.Translate(0, -offsetY, 0);
            if (GameObject.Find(handRightName) == null)
            {
                controlerModelLeft.SetActive(true);
            }
            else
            {
                GameObject.Find(handRightName).transform.parent = handRight.transform;
                controlerModelLeft.SetActive(false);
            }
            if (GameObject.Find(handRightName) == null)
            {
                controlerModelRight.SetActive(true);
            }
            else
            {
                controlerModelRight.SetActive(false);
                GameObject.Find(handLeftName).transform.parent = handLeft.transform;
            }
            
            //if(GameObject.Find(cameraName).GetComponent<Camera>()) GameObject.Find(cameraName).GetComponent<Camera>().targetTexture = renderTexture;
            
            if (hideHand == true) GameObject.Find(handRightName).GetComponent<MeshRenderer>().enabled = false;
            if (hideHand == true) GameObject.Find(handLeftName).GetComponent<MeshRenderer>().enabled = false;
            if (canvasName != "")
            {
                canvasC = GameObject.Find(canvasName);
                canvasC.GetComponent<Canvas>().renderMode = RenderMode.WorldSpace;
                canvasC.transform.parent = canvasParent.transform;
                canvasC.GetComponent<Canvas>().worldCamera = vrCamera.GetComponent<Camera>();
                canvasC.transform.localScale = new Vector3(1, 1, 1);
                canvasC.transform.localPosition = new Vector3(0, 0, 0);
                //canvasC.GetComponent<RectTransform>().sizeDelta = new Vector2(2, 2);
                //canvasC.GetComponent<Canvas>().planeDistance = 5.6f;

            }
            else
            {
                StartCoroutine(CanvasUpdate());
                for (int i = 0; i < GameObject.FindObjectsOfType<Canvas>(true).Length; i++)
                {

                    canvasC = GameObject.FindObjectsOfType<Canvas>()[i].gameObject;
                    if (canvasC.GetComponent<Canvas>().renderMode != RenderMode.WorldSpace)
                    {

                        canvasC.GetComponent<Canvas>().renderMode = RenderMode.WorldSpace;
                        canvasC.transform.parent = canvasParent.transform;
                        canvasC.GetComponent<Canvas>().worldCamera = vrCamera.GetComponent<Camera>();
                        canvasC.transform.localScale = new Vector3(1, 1, 1);
                        canvasC.transform.localPosition = new Vector3(0, 0, 0);
                        //canvasC.GetComponent<RectTransform>().sizeDelta = new Vector2(2, 2);
                    }
                }
            }
            vrCamera.GetComponent<Camera>().clearFlags = gameCamera.GetComponent<Camera>().clearFlags;
            vrCamera.GetComponent<Camera>().backgroundColor = gameCamera.GetComponent<Camera>().backgroundColor;
        }
        uint qsize = 15;  
        Queue myLogQueue = new Queue();
       

       
        void Start()
        {      
            
            currentController = InputDevices.GetDeviceAtXRNode(controller == PXR_Input.Controller.LeftController
                 ? XRNode.LeftHand
                 : XRNode.RightHand);
            Invoke("StartVrFunctions", 1);

        }
        private void OnLevelWasLoaded(int level)
        {
            
            for (int i = 0; i < canvasParent.transform.childCount; i++) {
                Destroy(canvasParent.transform.GetChild(i));
            }
            
            Invoke("StartVrFunctions", 1);
        }
        void Update()
        {
            transform.position = new Vector3(gameCamera.transform.position.x, gameCamera.transform.position.y, gameCamera.transform.position.z);
        }
        public IEnumerator CanvasUpdate()
        {
            while (true) {
                if (GameObject.Find(handRightName) == null)
                {
                    controlerModelLeft.SetActive(true);
                }
                else
                {
                    GameObject.Find(handRightName).transform.parent = handRight.transform;
                    controlerModelLeft.SetActive(false);
                }
                if (GameObject.Find(handRightName) == null)
                {
                    controlerModelRight.SetActive(true);
                }
                else
                {
                    controlerModelRight.SetActive(false);
                    GameObject.Find(handLeftName).transform.parent = handLeft.transform;
                }

                if (cameraName != "")
                {
                    gameCamera = GameObject.Find(cameraName);
                }
                else
                {
                    for (int i = 0; i < Camera.allCameras.Length; i++)
                    {
                        if (Camera.allCameras[i].targetTexture == null && Camera.allCameras[i].gameObject != vrCamera)
                        {
                            gameCamera = Camera.allCameras[i].gameObject;
                            break;
                        }

                    }
                }
                print("Canvas update");
                try
                {
                    for (int i = 0; i < GameObject.FindObjectsOfType<Canvas>(true).Length; i++)
                    {

                        canvasC = GameObject.FindObjectsOfType<Canvas>()[i].gameObject;
                        if (canvasC.GetComponent<Canvas>().renderMode != RenderMode.WorldSpace)
                        {

                            canvasC.GetComponent<Canvas>().renderMode = RenderMode.WorldSpace;
                            canvasC.transform.parent = canvasParent.transform;
                            canvasC.GetComponent<Canvas>().worldCamera = vrCamera.GetComponent<Camera>();
                            canvasC.transform.localScale = new Vector3(1, 1, 1);
                            canvasC.transform.localPosition = new Vector3(0, 0, 0);
                            Vector3 rot = new Vector3(0, 0, 0);
                            canvasC.transform.localRotation = Quaternion.Euler(rot.x,rot.y, rot.z);
                            //canvasC.GetComponent<RectTransform>().sizeDelta = new Vector2(2, 2);
                        }
                    }
                }
                catch
                {
                    Debug.LogError("Canvas error");
                }
                
                yield return new WaitForSeconds(0.5f);
            }
        }
       
    }
}
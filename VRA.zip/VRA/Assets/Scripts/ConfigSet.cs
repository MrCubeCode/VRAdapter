using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using Unity.XR.PXR;
using UnityEngine;
using UnityEngine.Networking;

public class ConfigSet : MonoBehaviour
{
    public Adapt vrAdapter;
    void Start()
    {
        StartCoroutine(Decode());
    }
   
    public IEnumerator Decode()
    {
        string path = $"{Application.streamingAssetsPath}/config.txt";
        UnityWebRequest www = UnityWebRequest.Get(path);
        yield return www.SendWebRequest();
        string data = www.downloadHandler.text;
        string[] commands = data.Split("\n");
        foreach (string command in commands) {
            string val =command.Split('=')[1];
            string editObject = command.Split('=')[0];
            if (editObject == "camera")
            {
                vrAdapter.cameraName = val;
            }
            if (editObject == "handLeft")
            {
                vrAdapter.handLeftName = val;
            }
            if (editObject == "handRight")
            {
                vrAdapter.handRightName = val;
            }
            if (editObject == "canvas")
            {
                vrAdapter.canvasName = val;
            }
        }
    }
}

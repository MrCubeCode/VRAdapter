using System.Collections;
using System.Collections.Generic;
using System.Threading;
using Unity.XR.PXR;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.XR;
using Zinnia.Event.Yield;
using static System.Runtime.CompilerServices.RuntimeHelpers;

public static class InputObjectVr
{
    public static GameObject VrAdapterObject;
    public static KeySimulate VrAdapterInput;
}
namespace Unity.XR.PXR
{
    public class KeySimulate : MonoBehaviour
    {
        public GameObject VrCam;
        public Vector3 lastRot;
        public int selected;
        public void Start()
        {
            StartCoroutine(CanvasControl());
        }
        private void OnLevelWasLoaded(int level)
        {
            selected = 0;
        }
        public IEnumerator CanvasControl()
        {
            while (true)
            {
                yield return new WaitForSeconds(1);
                try
                {
                    print("wait");
                    float grip;
                    float trigger;
                    bool button;
                    bool button2;
                    InputDevice currentController = InputDevices.GetDeviceAtXRNode(XRNode.LeftHand);
                    currentController.TryGetFeatureValue(CommonUsages.grip, out grip);
                    currentController.TryGetFeatureValue(CommonUsages.trigger, out trigger);
                    currentController.TryGetFeatureValue(CommonUsages.secondaryButton, out button);
                    currentController.TryGetFeatureValue(CommonUsages.primaryButton, out button2);
                    Button[] Buttons = GameObject.FindObjectsOfType<Button>();
                    var x = UnityEngine.Input.GetAxis("Horizontal") * Time.deltaTime;
                    var z = UnityEngine.Input.GetAxis("Vertical") * Time.deltaTime;

                    if (z >= 0.01f)
                    {
                        selected += 1;
                    }
                    if (z <= -0.01f)
                    {
                        selected -= 1;
                    }
                    if (selected < 0)
                    {
                        selected = Buttons.Length - 1;
                    }
                    if (selected >= Buttons.Length)
                    {
                        selected = 0;
                    }
                    if (button || UnityEngine.Input.GetKey(KeyCode.E))
                    {
                        Buttons[selected].onClick.Invoke();
                    }
                    for (int i = 0; i < Buttons.Length; i++)
                    {
                        if (i == selected)
                        {
                            Buttons[i].gameObject.GetComponent<Image>().color = new Color(Buttons[i].gameObject.GetComponent<Image>().color.r, Buttons[i].gameObject.GetComponent<Image>().color.g, Buttons[i].gameObject.GetComponent<Image>().color.b, 1);
                        }
                        else
                        {
                            Buttons[i].gameObject.GetComponent<Image>().color = new Color(Buttons[i].gameObject.GetComponent<Image>().color.r, Buttons[i].gameObject.GetComponent<Image>().color.g, Buttons[i].gameObject.GetComponent<Image>().color.b, 0.5f);
                        }
                    }
                }
                catch {
                    Debug.LogError("errorButtons");
                }
            }
        }
        public bool GetKeyVr(KeyCode keyCode)
        {
            if (UnityEngine.Input.anyKey)
            {
                float grip;
                float trigger;
                bool button;
                bool button2;
                InputDevice currentController = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
                currentController.TryGetFeatureValue(CommonUsages.grip, out grip);
                currentController.TryGetFeatureValue(CommonUsages.trigger, out trigger);
                currentController.TryGetFeatureValue(CommonUsages.secondaryButton, out button);
                currentController.TryGetFeatureValue(CommonUsages.primaryButton, out button2);
                var x = UnityEngine.Input.GetAxis("Horizontal") * Time.deltaTime;
                var z = UnityEngine.Input.GetAxis("Vertical") * Time.deltaTime;
                if (UnityEngine.Input.GetKey(keyCode) == true)
                {
                    return true;
                }
                if (button && keyCode == KeyCode.E)
                {
                    return true;
                }
                if (button2 && keyCode == KeyCode.Space)
                {
                    return true;
                }
                if (grip >= 0.01f && keyCode == KeyCode.LeftControl)
                {
                    return true;
                }
                if (trigger >= 0.01f && keyCode == KeyCode.Mouse0)
                {
                    return true;
                }
                if (z >= 0.01f && keyCode == KeyCode.W)
                {
                    return true;
                }
                if (z <= -0.01f && keyCode == KeyCode.S)
                {
                    return true;
                }
                if (x >= 0.01f && keyCode == KeyCode.D)
                {
                    return true;
                }
                if (x <= -0.01f && keyCode == KeyCode.A)
                {
                    return true;
                }
                if (grip > 0.01f && keyCode == KeyCode.A)
                {
                    return true;
                }
                currentController = InputDevices.GetDeviceAtXRNode(XRNode.LeftHand);
                currentController.TryGetFeatureValue(CommonUsages.grip, out grip);
                currentController.TryGetFeatureValue(CommonUsages.trigger, out trigger);
                currentController.TryGetFeatureValue(CommonUsages.secondaryButton, out button);
                currentController.TryGetFeatureValue(CommonUsages.primaryButton, out button2);
                if (button && keyCode == KeyCode.Q)
                {
                    return true;
                }
                if (button2 && keyCode == KeyCode.F)
                {
                    return true;
                }
                if (grip >= 0.01f && keyCode == KeyCode.LeftShift)
                {
                    return true;
                }
                if (trigger >= 0.01f && keyCode == KeyCode.Mouse0)
                {
                    return true;
                }
               
            }
            return false;
        }
        public bool GetKeyVrDown(KeyCode keyCode)
        {
            return GetKeyVr(keyCode);
        }
        public bool GetKeyVrUp(KeyCode keyCode)
        {
            return GetKeyVr(keyCode);
        }
        public float GetAxisVr(string mode)
        {
             
            float returnValve = UnityEngine.Input.GetAxis(mode);
            //Forward
            var x = UnityEngine.Input.GetAxis("Horizontal") * Time.deltaTime;
            var z = UnityEngine.Input.GetAxis("Vertical") * Time.deltaTime;
            
            if (mode == "Mouse Z")
            {
                returnValve = lastRot.z - VrCam.transform.rotation.eulerAngles.z;
            }

            if (mode == "Mouse X")
            {
                returnValve = lastRot.y - VrCam.transform.rotation.eulerAngles.y;
            }
            if (mode == "Mouse Y")
            {
                returnValve = lastRot.x - VrCam.transform.rotation.eulerAngles.x;
                
            }
            
            lastRot = new Vector3(VrCam.transform.rotation.eulerAngles.x, VrCam.transform.rotation.eulerAngles.y, VrCam.transform.rotation.eulerAngles.z);
            return -returnValve;
        }
        public AsyncOperation LoadSceneVr(object name)
        {
            AsyncOperation asyncLoad;
            Scene sceneValid;
            if (name.GetType() == typeof(string))
            {
                Scene currentScene = SceneManager.GetActiveScene();
                 asyncLoad = SceneManager.LoadSceneAsync(name.ToString(), LoadSceneMode.Additive);

                sceneValid = SceneManager.GetSceneByName(name.ToString());
            }
            else 
            {
                Scene currentScene = SceneManager.GetActiveScene();
                asyncLoad = SceneManager.LoadSceneAsync(int.Parse(name.ToString())+1, LoadSceneMode.Additive);
                sceneValid = SceneManager.GetSceneByBuildIndex(int.Parse(name.ToString()));

            }
            

            // ���������, ���������� �� �����
            if (sceneValid.IsValid())
            {
                SceneManager.UnloadSceneAsync(SceneManager.GetAllScenes()[1]);
            }
            return asyncLoad;
        }
        public AsyncOperation LoadSceneAsyncVr(object name)
        {
            return LoadSceneVr(name);
        }
    }
   

}
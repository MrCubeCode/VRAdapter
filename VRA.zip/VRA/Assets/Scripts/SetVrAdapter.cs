using System.Collections;
using System.Collections.Generic;
using Unity.XR.PXR;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SetVrAdapter : MonoBehaviour
{
    public Adapt vrAdapter;
    public int m_Scene;
    private void Start()
    {
        StartCoroutine(LoadAsyncScene());
    }
    IEnumerator LoadAsyncScene()
    {
        Scene currentScene = SceneManager.GetActiveScene();
        m_Scene = 1;
        AsyncOperation asyncLoad = SceneManager.LoadSceneAsync(m_Scene, LoadSceneMode.Additive);
        while (!asyncLoad.isDone)
        {
            yield return null;
        }
    }
}

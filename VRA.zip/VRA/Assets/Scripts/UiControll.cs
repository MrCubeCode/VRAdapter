using System.Collections;
using System.Collections.Generic;
using Unity.XR.PXR;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.UIElements;

public class UiControll : MonoBehaviour
{
    public InputField inputField;
    public Adapt vrAdapter;
    [SerializeField] private OptionsVal valEdit;
    private enum OptionsVal { Left, Right, Camera }
    public void Pressed()
    {
        inputField.ActivateInputField();
    }
    public void Edit()
    {
        if (valEdit == OptionsVal.Left) {
            vrAdapter.handLeftName = inputField.text;
        }
        if (valEdit == OptionsVal.Right)
        {
            vrAdapter.handRightName = inputField.text;
        }
        if (valEdit == OptionsVal.Camera)
        {
            vrAdapter.cameraName = inputField.text;
        }
    }
}
